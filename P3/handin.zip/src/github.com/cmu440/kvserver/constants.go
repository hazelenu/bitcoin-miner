package kvserver

const (
	minSyncInterval   = 100
	heartbeatInterval = 250
)
